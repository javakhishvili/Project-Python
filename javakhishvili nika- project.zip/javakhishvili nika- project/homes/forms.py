from django import forms
from .models import Home



class HomeForm(forms.ModelForm):
    class Meta:
        model = Home
        fields = ['user', 'home_main_img']
        
      


# class ImageUploadForm(forms.ModelForm):
#     class Meta:
#         model = Home
#         fields = ['image']
