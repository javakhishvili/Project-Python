from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class Home(models.Model):
   user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
   city = models.CharField(max_length=100)
   address = models.CharField(max_length=100)
   publication_date = models.CharField(max_length=15)
   number = models.CharField(max_length=11)
   url = models.URLField(blank=True)
   # image = models.ImageField(upload_to='homes/images')
   home_main_img = models.ImageField(upload_to="media/images", default='images/default.jpg')

   def __sts__(self):
      return self.user